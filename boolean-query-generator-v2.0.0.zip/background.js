// ============================================
// Background Service Worker
// ============================================
// Minimal background script - API removed, using static data

console.log("[Background] Service worker loaded - using static data only");

// No API calls needed - all data is static
